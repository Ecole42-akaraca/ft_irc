
#include <sys/socket.h>
#include "bircd.h"

void	client_write(t_env *e, int cs)
{
}
