#include "../../headers/Server.hpp"

void	Server::cap(int fd, std::vector<std::string> tokens) {
	(void)tokens;
	ft_write(fd, "");
}
